import { useMemo, useState } from 'react'

import { analyzeQuery } from '../api/studio'
import BenchmarkBarChart from '../components/studio/BenchmarkBarChart'

const SAMPLE_QUERIES = [
  `SELECT * FROM orders WHERE customer_id = 845;`,
  `SELECT * FROM products WHERE price BETWEEN 1000 AND 3000;`,
  `SELECT c.customer_id, c.name, COUNT(o.order_id) AS number_of_orders, SUM(o.total_amount) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE c.segment = 'Corporate'
GROUP BY c.customer_id, c.name
ORDER BY total_spent DESC
LIMIT 20;`,
]

const CANDIDATE_TYPE_STYLES = {
  INDEX: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  SQL_REWRITE: 'bg-violet-50 text-violet-700 border-violet-200',
  ARCHITECTURAL: 'bg-amber-50 text-amber-700 border-amber-200',
}

const EVIDENCE_STYLES = {
  COMPLETE: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  PARTIAL: 'bg-amber-50 text-amber-700 border-amber-200',
  INSUFFICIENT: 'bg-slate-100 text-slate-500 border-slate-200',
}

function Badge({ children, className }) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[0.68rem] font-semibold uppercase tracking-wide ${className}`}
    >
      {children}
    </span>
  )
}

function StudioPage() {
  const [sql, setSql] = useState(SAMPLE_QUERIES[2])
  const [sampleIndex, setSampleIndex] = useState(2)
  const [runBenchmark, setRunBenchmark] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [result, setResult] = useState(null)
  const [selectedCandidateId, setSelectedCandidateId] = useState(null)

  async function handleAnalyze() {
    setLoading(true)
    setError(null)
    setSelectedCandidateId(null)

    try {
      const data = await analyzeQuery({ sql, runBenchmark })
      setResult(data)
    } catch (requestError) {
      setError(requestError.message)
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  function loadNextSample() {
    const next = (sampleIndex + 1) % SAMPLE_QUERIES.length
    setSampleIndex(next)
    setSql(SAMPLE_QUERIES[next])
  }

  const report = result?.report
  const candidates = report?.candidates ?? []
  const benchmarkEvidence = report?.benchmark_evidence ?? []

  const selectedCandidate = useMemo(
    () => candidates.find((c) => c.candidate_id === selectedCandidateId) ?? null,
    [candidates, selectedCandidateId],
  )

  const chartData = useMemo(() => {
    return benchmarkEvidence
      .filter((e) => e.evidence_status === 'COMPLETE')
      .flatMap((e) => [
        { label: `${e.candidate_id} (before)`, value: e.baseline_time_ms ?? 0, color: '#f87171', candidateId: e.candidate_id },
        { label: `${e.candidate_id} (after)`, value: e.alternative_time_ms ?? 0, color: '#4fd1c5', candidateId: e.candidate_id },
      ])
  }, [benchmarkEvidence])

  return (
    <div className="space-y-6">
      <section className="dashboard-page-header mb-0">
        <div className="relative z-10">
          <div className="mb-2 flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-amber-500 shadow-[0_0_0_4px_rgba(245,158,11,0.10)]" />
            <span className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-amber-600">
              M21 Dynamic Structural SQL Optimization
            </span>
          </div>
          <h2 className="text-[1.7rem] font-bold tracking-[-0.03em] text-slate-950">
            SQL Optimization Studio
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
            Submit any SELECT query and run it through the full validate → structural
            analysis → candidate generation → benchmark → report pipeline.
          </p>
        </div>
      </section>

      <div className="dashboard-card p-6">
        <h3 className="dashboard-section-title mb-3">Submit a query</h3>
        <textarea
          value={sql}
          onChange={(e) => setSql(e.target.value)}
          spellCheck={false}
          rows={7}
          className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-[0.8rem] text-slate-800 focus:border-indigo-400 focus:outline-none"
        />
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleAnalyze}
            disabled={loading}
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"
          >
            {loading ? 'Analyzing…' : 'Analyze query'}
          </button>
          <button
            type="button"
            onClick={loadNextSample}
            className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-500 hover:text-slate-800"
          >
            Load another sample
          </button>
          <label className="flex items-center gap-2 text-sm text-slate-500">
            <input
              type="checkbox"
              checked={runBenchmark}
              onChange={(e) => setRunBenchmark(e.target.checked)}
            />
            Run live benchmark (executes SQL against the database)
          </label>
        </div>
        {error && (
          <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-700">{error}</p>
        )}
      </div>

      {report && (
        <>
          {/* Section 1 — Query Validation */}
          <div className="dashboard-card p-6">
            <h3 className="dashboard-section-title mb-2">1. Query Validation</h3>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <Badge
                className={
                  report.query_validation.status === 'VALID'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200'
                }
              >
                {report.query_validation.status}
              </Badge>
              <span className="text-slate-500">{report.query_validation.message}</span>
            </div>
          </div>

          {/* Section 2 — Structural Analysis */}
          <div className="dashboard-card p-6">
            <h3 className="dashboard-section-title mb-3">2. Structural Analysis</h3>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                ['Tables', report.structural_analysis.tables?.length ?? 0],
                ['Joins', report.structural_analysis.joins_detected ?? 0],
                ['Aggregates', report.structural_analysis.aggregates_detected ?? 0],
                ['Subqueries', report.structural_analysis.subqueries_detected ?? 0],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                  <p className="text-xl font-bold text-slate-900">{value}</p>
                  <p className="text-[0.68rem] text-slate-400">{label}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-slate-400">
              Layers detected: {report.structural_analysis.layers_detected?.join(', ') || '—'}
            </p>
          </div>

          {/* Section 3 — Candidates */}
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="dashboard-card p-6">
              <h3 className="dashboard-section-title mb-3">
                3. Candidates <span className="text-slate-400">({candidates.length})</span>
              </h3>
              {candidates.length === 0 ? (
                <p className="text-sm text-slate-400">No optimization candidates identified.</p>
              ) : (
                <div className="space-y-2">
                  {candidates.map((candidate) => (
                    <button
                      key={candidate.candidate_id}
                      type="button"
                      onClick={() => setSelectedCandidateId(candidate.candidate_id)}
                      className={`block w-full rounded-lg border p-3 text-left transition ${
                        selectedCandidateId === candidate.candidate_id
                          ? 'border-indigo-300 bg-indigo-50'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="mb-1 flex flex-wrap items-center gap-2">
                        <Badge className={CANDIDATE_TYPE_STYLES[candidate.alternative_type] || ''}>
                          {candidate.alternative_type}
                        </Badge>
                        <span className="text-xs font-mono text-slate-400">{candidate.candidate_id}</span>
                      </div>
                      <p className="text-sm font-semibold text-slate-800">{candidate.title}</p>
                      <p className="mt-1 text-xs text-slate-500 line-clamp-2">{candidate.rationale}</p>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="dashboard-card p-6">
              <h3 className="dashboard-section-title mb-3">Candidate SQL</h3>
              {selectedCandidate ? (
                <pre className="max-h-72 overflow-auto rounded-lg bg-slate-900 p-3 text-[0.72rem] leading-5 text-slate-100">
                  {selectedCandidate.optimized_sql ||
                    selectedCandidate.index_ddl ||
                    selectedCandidate.architectural_recommendation ||
                    '-- No rewritten SQL generated yet for this candidate.'}
                </pre>
              ) : (
                <p className="text-sm text-slate-400">Select a candidate to preview its SQL.</p>
              )}
            </div>
          </div>

          {/* Section 4 — Benchmark Evidence */}
          <div className="dashboard-card p-6">
            <h3 className="dashboard-section-title mb-3">4. Benchmark Evidence</h3>
            {benchmarkEvidence.length === 0 ? (
              <p className="text-sm text-slate-400">
                {runBenchmark
                  ? 'No benchmark evidence returned.'
                  : 'Benchmarking was not run for this analysis — enable "Run live benchmark" above to measure real execution time.'}
              </p>
            ) : (
              <div className="grid gap-4 lg:grid-cols-2">
                <div>
                  {chartData.length > 0 ? (
                    <BenchmarkBarChart data={chartData} />
                  ) : (
                    <p className="text-sm text-slate-400">No COMPLETE benchmark comparisons to chart.</p>
                  )}
                </div>
                <div className="space-y-2">
                  {benchmarkEvidence.map((e) => (
                    <div key={e.candidate_id} className="rounded-lg border border-slate-200 p-3">
                      <div className="mb-1 flex items-center justify-between">
                        <span className="text-xs font-mono text-slate-400">{e.candidate_id}</span>
                        <Badge className={EVIDENCE_STYLES[e.evidence_status] || ''}>
                          {e.evidence_status}
                        </Badge>
                      </div>
                      {e.evidence_status === 'COMPLETE' && (
                        <p className="text-xs text-slate-500">
                          {e.baseline_time_ms?.toFixed(1)}ms → {e.alternative_time_ms?.toFixed(1)}ms
                          {' '}({e.improvement_percent > 0 ? '−' : '+'}
                          {Math.abs(e.improvement_percent ?? 0).toFixed(1)}%)
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Section 5 — Overall Evidence Status */}
          <div className="dashboard-card p-6">
            <h3 className="dashboard-section-title mb-2">5. Overall Evidence Status</h3>
            <Badge className={EVIDENCE_STYLES[report.overall_evidence_status] || ''}>
              {report.overall_evidence_status}
            </Badge>
          </div>

          {result.diagnostics?.length > 0 && (
            <div className="dashboard-card border-amber-200 bg-amber-50 p-4">
              <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-amber-700">
                Pipeline diagnostics
              </p>
              <ul className="list-inside list-disc text-xs text-amber-800">
                {result.diagnostics.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}
    </div>
  )
}

export default StudioPage
