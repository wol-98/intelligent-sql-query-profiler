/**
 * M21.17 — Benchmark comparison chart with cross-filtering.
 *
 * No charting library is currently in dashboard/package.json (only
 * react/react-dom/tailwind), so this is a small hand-built SVG bar
 * chart rather than adding a new dependency for one chart. If the
 * team later wants richer charts across the dashboard, swapping this
 * for e.g. recharts would be a contained change — this component's
 * props (data, onBarClick) are chart-library-agnostic on purpose.
 */

function BenchmarkBarChart({ data, onBarClick, selectedLabel }) {
  const width = 420
  const height = 220
  const paddingLeft = 50
  const paddingBottom = 30
  const paddingTop = 16
  const chartWidth = width - paddingLeft - 20
  const chartHeight = height - paddingBottom - paddingTop

  const maxValue = Math.max(1, ...data.map((d) => d.value))
  const barWidth = chartWidth / data.length - 24

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" role="img" aria-label="Benchmark comparison chart">
      {[0, 0.25, 0.5, 0.75, 1].map((fraction) => {
        const y = paddingTop + chartHeight * (1 - fraction)
        return (
          <g key={fraction}>
            <line
              x1={paddingLeft}
              x2={width - 20}
              y1={y}
              y2={y}
              stroke="#e2e8f0"
              strokeWidth="1"
            />
            <text x={paddingLeft - 8} y={y + 4} textAnchor="end" className="fill-slate-400" fontSize="10">
              {Math.round(maxValue * fraction)}
            </text>
          </g>
        )
      })}

      {data.map((d, i) => {
        const barHeight = (d.value / maxValue) * chartHeight
        const x = paddingLeft + i * (chartWidth / data.length) + 12
        const y = paddingTop + chartHeight - barHeight
        const isSelected = selectedLabel === d.label

        return (
          <g
            key={d.label}
            onClick={() => onBarClick?.(d)}
            style={{ cursor: onBarClick ? 'pointer' : 'default' }}
          >
            <rect
              x={x}
              y={y}
              width={barWidth}
              height={barHeight}
              rx="4"
              fill={d.color || '#6366f1'}
              opacity={isSelected || !selectedLabel ? 1 : 0.4}
            />
            <text
              x={x + barWidth / 2}
              y={y - 6}
              textAnchor="middle"
              fontSize="11"
              className="fill-slate-700 font-semibold"
            >
              {d.value.toFixed(1)}
            </text>
            <text
              x={x + barWidth / 2}
              y={height - paddingBottom + 16}
              textAnchor="middle"
              fontSize="11"
              className="fill-slate-500"
            >
              {d.label}
            </text>
          </g>
        )
      })}
    </svg>
  )
}

export default BenchmarkBarChart
