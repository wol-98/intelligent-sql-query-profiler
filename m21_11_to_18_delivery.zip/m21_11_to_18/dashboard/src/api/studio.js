const API_BASE_URL = 'http://127.0.0.1:8000'

export async function analyzeQuery({
  sql,
  executionFrequency = 1,
  wherePredicateColumns = [],
  runBenchmark = false,
}) {
  const response = await fetch(`${API_BASE_URL}/api/studio/analyze`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      sql,
      execution_frequency: executionFrequency,
      where_predicate_columns: wherePredicateColumns,
      run_benchmark: runBenchmark,
    }),
  })

  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error(body.detail || `Analysis request failed with status ${response.status}`)
  }

  return response.json()
}
