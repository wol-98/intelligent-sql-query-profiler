"""
Studio API Schemas (M21.16 backend)
--------------------------------------
Request/response shapes for POST /api/studio/analyze. The response
wraps the existing OptimizationReport (the real five-section report,
see optimization_report_builder.py) plus non-schema diagnostics text
for the UI to display (reasons a stage was skipped, benchmark
failures, etc. — see structural_benchmark_service.BenchmarkDiagnostics).
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from api.schemas.structural_optimization import OptimizationReport


class StudioAnalyzeRequest(BaseModel):
    sql: str
    execution_frequency: int = Field(
        default=1,
        ge=1,
        description=(
            "How often this exact query shape has been observed to run. "
            "Leave at 1 for a one-off ad-hoc submission."
        ),
    )
    where_predicate_columns: list[str] = Field(default_factory=list)
    run_benchmark: bool = Field(
        default=False,
        description=(
            "If true, executes the candidates' rewritten SQL against the "
            "live database for real timing. Should require explicit user "
            "confirmation in the UI, not be the default action."
        ),
    )


class StudioAnalyzeResponse(BaseModel):
    report: OptimizationReport
    diagnostics: list[str] = Field(default_factory=list)
