"""
M21.13 — Integrated Index + Structural Optimization
-------------------------------------------------------
Combines candidates from every M21 candidate-generating stage into
one deduplicated, OptimizationReport-ready list of OptimizationCandidate
objects:

  - StructuralCandidateGenerator          (M21.4-9)  -> INDEX / SQL_REWRITE
  - StructuralSubqueryCandidateGenerator  (M21.7)     -> StructuralAlternativeCandidate
                                                          (EXISTS/IN/ANY/derived table)
  - ArchitecturalViewRecommender          (M21.11)    -> ARCHITECTURAL
  - ArchitecturalFunctionRecommender      (M21.12)    -> ARCHITECTURAL

StructuralAlternativeCandidate is a different Pydantic model from
OptimizationCandidate (see api/schemas/structural_optimization.py) —
it carries subquery-specific fields (semantic_safety, alternative_sql)
that OptimizationCandidate does not have. This module converts each
StructuralAlternativeCandidate into an OptimizationCandidate so the
final report has one uniform candidate list, folding the semantic-
safety status into the rationale text since OptimizationCandidate has
no field for it.

This service is analytical only. It does not validate, benchmark, or
make production decisions — see structural_benchmark_service.py
(M21.14) and the M19 production-decision framework for those stages.
"""

from __future__ import annotations

from api.schemas.structural_optimization import (
    AlternativeType,
    OptimizationCandidate,
    StructuralAlternativeCandidate,
)

_SUBQUERY_CANDIDATE_ID_PREFIX = "SQL-REWRITE-FROM-SUBQ"


def _convert_subquery_candidate(
    candidate: StructuralAlternativeCandidate,
) -> OptimizationCandidate:
    """
    Converts a StructuralAlternativeCandidate (EXISTS/IN/ANY/derived
    table) into an OptimizationCandidate with alternative_type=SQL_REWRITE,
    preserving its candidate_id, status, and original SQL, and folding
    semantic_safety + evidence_status into the rationale text.
    """

    rationale = (
        f"{candidate.rationale} "
        f"[semantic safety: {candidate.semantic_safety.value}; "
        f"evidence status: {candidate.evidence_status.value}]"
    )

    return OptimizationCandidate(
        candidate_id=candidate.candidate_id,
        alternative_type=AlternativeType.SQL_REWRITE,
        status=candidate.status,
        title=candidate.title,
        rationale=rationale,
        source_layer=candidate.source_layer,
        original_sql=candidate.original_sql,
        optimized_sql=candidate.alternative_sql,
        index_ddl=None,
        architectural_recommendation=None,
    )


def _table_touched_by_architectural(
    architectural_candidate: OptimizationCandidate, table_name: str
) -> bool:
    sql = (architectural_candidate.architectural_recommendation or "").lower()
    return bool(table_name) and table_name.lower() in sql


def aggregate_candidates(
    *,
    structural_candidates: list[OptimizationCandidate],
    subquery_candidates: list[StructuralAlternativeCandidate],
    architectural_candidates: list[OptimizationCandidate],
    tables: list[str] | None = None,
) -> list[OptimizationCandidate]:
    """
    Returns one combined, deduplicated list of OptimizationCandidate
    objects ready to place in OptimizationReport.candidates.

    Deduplication rule: if a MATERIALIZED VIEW candidate (from
    architectural_candidates) already covers one of `tables`, index
    candidates from structural_candidates targeting the same table
    are flagged in their rationale as possibly redundant — not
    silently dropped, since the team may still want both applied
    while the materialized view is being evaluated.
    """

    tables = tables or []
    combined: list[OptimizationCandidate] = []

    materialized_view_candidates = [
        c
        for c in architectural_candidates
        if c.alternative_type == AlternativeType.ARCHITECTURAL
        and c.architectural_recommendation
        and "MATERIALIZED VIEW" in c.architectural_recommendation.upper()
    ]

    for candidate in structural_candidates:
        if candidate.alternative_type == AlternativeType.INDEX:
            covering_view = next(
                (
                    mv
                    for table in tables
                    for mv in materialized_view_candidates
                    if _table_touched_by_architectural(mv, table)
                ),
                None,
            )
            if covering_view is not None:
                candidate = candidate.model_copy(
                    update={
                        "rationale": (
                            f"{candidate.rationale} "
                            f"[flag: possibly redundant — materialized view "
                            f"candidate {covering_view.candidate_id} already "
                            f"covers a related table; review before applying both]"
                        )
                    }
                )
        combined.append(candidate)

    combined.extend(architectural_candidates)
    combined.extend(_convert_subquery_candidate(c) for c in subquery_candidates)

    return combined
