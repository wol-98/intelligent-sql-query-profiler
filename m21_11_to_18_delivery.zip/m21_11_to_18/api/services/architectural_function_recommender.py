"""
M21.12 — Architectural Function Recommender
----------------------------------------------
Recommends wrapping a frequently-run, predicate-driven query in a
PostgreSQL SQL function, when the query's shape is stable (same
fingerprint) but its literal filter values vary between executions.
This is the parameterization case — distinct from M21.11's view
case, which is for queries that are always identical.

This service is analytical only — same constraints as
architectural_view_recommender.py. It produces a SQL SKELETON, not
production-ready code: parameter types are inferred from column-name
conventions and MUST be checked against the real schema
(api/services/schema_introspector.py) before use. This limitation is
intentional and stated here rather than silently assumed correct.
"""

from __future__ import annotations

from api.schemas.structural_optimization import (
    AlternativeType,
    CandidateStatus,
    OptimizationCandidate,
    StructuralAnalysis,
    StructuralFinding,
    StructuralLayer,
)

FREQUENCY_THRESHOLD = 3  # higher bar than views — this is a bigger structural change


class ArchitecturalFunctionRecommender:
    """Recommend a parameterized SQL function for high-frequency,
    predicate-driven queries."""

    def recommend(
        self,
        analysis: StructuralAnalysis,
        original_sql: str,
        *,
        execution_frequency: int,
        candidate_id: str,
        function_name: str,
        where_predicate_columns: list[str],
    ) -> OptimizationCandidate | None:
        """
        Parameters
        ----------
        where_predicate_columns : list[str]
            Column names (qualified or not) that appear in this
            query's WHERE clause. Callers should supply this from
            structural findings (StructuralFinding.evidence for
            layer=WHERE) or from query_parser.py's where_predicates —
            not re-derived here, to avoid a second parsing pass.
        """

        if execution_frequency < FREQUENCY_THRESHOLD:
            return None

        if not where_predicate_columns:
            return None

        where_layer_present = StructuralLayer.WHERE in analysis.layers_detected
        if not where_layer_present:
            return None

        function_sql = self._build_function_sql(
            function_name, original_sql, where_predicate_columns
        )

        rationale = (
            f"Same query shape observed {execution_frequency}x with different "
            f"filter values on {', '.join(where_predicate_columns)}. A "
            "parameterized function avoids re-planning the same shape "
            "repeatedly. This is a SQL SKELETON requiring human review before "
            "use — parameter types are guessed from column-name conventions, "
            "not looked up from the real schema, and no semantic equivalence "
            "or performance improvement has been established at this stage."
        )

        return OptimizationCandidate(
            candidate_id=candidate_id,
            alternative_type=AlternativeType.ARCHITECTURAL,
            status=CandidateStatus.CANDIDATE,
            title="Database function candidate",
            rationale=rationale,
            source_layer=StructuralLayer.WHERE,
            original_sql=original_sql,
            optimized_sql=None,
            index_ddl=None,
            architectural_recommendation=function_sql,
        )

    @staticmethod
    def _guess_param_type(column_name: str) -> str:
        """
        Rough type guess from column-name conventions. MUST be
        replaced with a real schema_introspector.py lookup before
        this SQL is used — see module docstring.
        """
        lowered = column_name.lower()
        if lowered.endswith("_id"):
            return "BIGINT"
        if "date" in lowered:
            return "TIMESTAMP"
        if "amount" in lowered or "price" in lowered or "total" in lowered:
            return "NUMERIC"
        return "TEXT"

    def _build_function_sql(
        self, function_name: str, original_sql: str, predicate_columns: list[str]
    ) -> str:
        params = []
        for column in predicate_columns:
            short_name = column.split(".")[-1]
            param_type = self._guess_param_type(short_name)
            params.append(f"p_{short_name} {param_type}")

        param_list = ", ".join(params)
        body = original_sql.strip().rstrip(";")

        todo_lines = "\n".join(
            f"-- TODO: replace literal for {col} with p_{col.split('.')[-1]}"
            for col in predicate_columns
        )

        return (
            f"CREATE OR REPLACE FUNCTION {function_name}({param_list})\n"
            f"RETURNS SETOF RECORD AS $$\n"
            f"{body}\n"
            f"{todo_lines}\n"
            f"$$ LANGUAGE sql STABLE;"
        )
