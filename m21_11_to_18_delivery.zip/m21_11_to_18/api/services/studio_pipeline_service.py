"""
Studio Pipeline Orchestrator (backend for M21.16)
------------------------------------------------------
Wires the full M21 target workflow together for one submitted query:

  USER SQL -> VALIDATE -> SCHEMA CHECK -> PARSE -> STRUCTURAL ANALYSIS
  -> CANDIDATE GENERATION -> SAFE VALIDATION -> BENCHMARK -> COST/BENEFIT
  -> REPORT

This module does not implement any pipeline stage itself — it only
calls the already-built M21.2-15 services in order and assembles
their outputs. If a stage's interface changes, this is the one file
that needs to change to match.

SCHEMA CHECK (M21.3) requires a live PostgreSQL connection via
SchemaIntrospector (api/services/schema_introspector.py). This
orchestrator treats schema validation as best-effort: if no DB
connection is available, schema checking is skipped (not failed) and
the report proceeds without it — flagged in the returned diagnostics
rather than silently pretended-successful. Whoever wires this to a
real environment should confirm this degrade-gracefully behavior is
what the team wants, versus hard-failing when schema checking is
unavailable.

BENCHMARKING is opt-in (run_benchmark=False by default) since it
executes real SQL against the database. The Studio UI should make
this an explicit, visible user action, not something that happens
just because someone clicked "Analyze."
"""

from __future__ import annotations

from dataclasses import dataclass, field

import sqlglot

from api.schemas.structural_optimization import (
    OptimizationCandidate,
    OptimizationReport,
    QueryValidationResult,
    QueryValidationStatus,
    StructuralAnalysis,
    StructuralAnalysisStatus,
)
from api.services.architectural_function_recommender import (
    ArchitecturalFunctionRecommender,
)
from api.services.architectural_view_recommender import ArchitecturalViewRecommender
from api.services.integrated_candidate_aggregator import aggregate_candidates
from api.services.optimization_report_builder import build_optimization_report
from api.services.schema_validator import extract_table_references
from api.services.structural_benchmark_service import benchmark_candidates
from api.services.structural_candidate_generator import StructuralCandidateGenerator
from api.services.structural_finding_classifier import StructuralFindingClassifier
from api.services.structural_opportunity_analyzer import StructuralOpportunityAnalyzer
from api.services.structural_sql_analyzer import StructuralSQLAnalyzer
from api.services.structural_sql_validator import validate_sql
from api.services.structural_subquery_candidate_generator import (
    StructuralSubqueryCandidateGenerator,
)


@dataclass
class StudioPipelineResult:
    report: OptimizationReport
    diagnostics: list[str] = field(default_factory=list)


def _next_candidate_id(existing: list[OptimizationCandidate], prefix: str, index: int) -> str:
    return f"{prefix}-{index:04d}"


def run_studio_pipeline(
    sql_text: str,
    *,
    execution_frequency: int = 1,
    where_predicate_columns: list[str] | None = None,
    run_benchmark: bool = False,
) -> StudioPipelineResult:
    """
    Runs the full M21 pipeline for one submitted query.

    Parameters
    ----------
    execution_frequency : int
        How often this exact query shape has been observed to run.
        Defaults to 1 (a single ad-hoc Studio submission) — pass a
        real value from query-fingerprint frequency tracking when
        calling this for known/repeated workload queries instead of
        one-off Studio submissions, since M21.11/12's thresholds are
        meaningless for a query with no execution history.
    where_predicate_columns : list[str] | None
        Columns from the WHERE clause, for M21.12's function
        recommender. Optional because a query may have no WHERE
        predicates at all.
    run_benchmark : bool
        Whether to execute candidates' rewritten SQL against the live
        database for real timing. False by default — see module
        docstring.
    """

    diagnostics: list[str] = []

    # ---------------------------------------------------------------
    # VALIDATE (M21.2)
    # ---------------------------------------------------------------

    validation = validate_sql(sql_text)

    if validation.status != QueryValidationStatus.VALID:
        empty_analysis = StructuralAnalysis(
            status=StructuralAnalysisStatus.INSUFFICIENT_EVIDENCE
        )
        report = build_optimization_report(validation, empty_analysis, [], [])
        diagnostics.append(f"Validation stopped the pipeline: {validation.message}")
        return StudioPipelineResult(report=report, diagnostics=diagnostics)

    normalized_sql = validation.normalized_query or sql_text

    # ---------------------------------------------------------------
    # SCHEMA CHECK (M21.3) — best-effort, requires live DB
    # ---------------------------------------------------------------

    try:
        expression = sqlglot.parse_one(normalized_sql, dialect="postgres")
        table_refs = extract_table_references(expression)
        tables = [ref.table for ref in table_refs]
    except Exception as exc:
        diagnostics.append(f"Could not extract table references: {exc}")
        expression = sqlglot.parse_one(normalized_sql, dialect="postgres")
        tables = []

    try:
        from api.services.schema_validator import validate_tables

        # validate_tables() creates its own SchemaIntrospector (which
        # opens a live DB connection via config/database.py) when none
        # is supplied — that's the call that raises if no DB is configured.
        schema_result = validate_tables(expression)
        if schema_result.missing_tables:
            diagnostics.append(
                f"Schema check found missing tables: {', '.join(schema_result.missing_tables)}"
            )
    except Exception as exc:
        diagnostics.append(
            f"Schema check skipped (no live DB connection available in this "
            f"environment): {exc}"
        )

    # ---------------------------------------------------------------
    # PARSE + STRUCTURAL ANALYSIS (M21.4)
    # ---------------------------------------------------------------

    analysis = StructuralSQLAnalyzer().analyze(
        expression, query_type=validation.query_type, tables=tables
    )

    # ---------------------------------------------------------------
    # CLASSIFICATION + OPPORTUNITY IDENTIFICATION (M21.5-9)
    # ---------------------------------------------------------------

    classifications = StructuralFindingClassifier().classify(analysis.findings)
    opportunities = StructuralOpportunityAnalyzer().analyze(analysis, classifications)

    # ---------------------------------------------------------------
    # CANDIDATE GENERATION (M21.4-9 base + M21.7 subquery + M21.11-12 new)
    # ---------------------------------------------------------------

    structural_candidates = StructuralCandidateGenerator().generate(
        analysis, opportunities, normalized_sql
    )

    subquery_result = StructuralSubqueryCandidateGenerator().generate(
        analysis, opportunities, normalized_sql
    )

    architectural_candidates: list[OptimizationCandidate] = []

    view_candidate = ArchitecturalViewRecommender().recommend(
        analysis,
        normalized_sql,
        execution_frequency=execution_frequency,
        candidate_id=_next_candidate_id(structural_candidates, "ARCH-VIEW", 1),
        view_name=f"vw_studio_{abs(hash(normalized_sql)) % 100000}",
    )
    if view_candidate is not None:
        architectural_candidates.append(view_candidate)

    if where_predicate_columns:
        function_candidate = ArchitecturalFunctionRecommender().recommend(
            analysis,
            normalized_sql,
            execution_frequency=execution_frequency,
            candidate_id=_next_candidate_id(structural_candidates, "ARCH-FUNC", 1),
            function_name=f"fn_studio_{abs(hash(normalized_sql)) % 100000}",
            where_predicate_columns=where_predicate_columns,
        )
        if function_candidate is not None:
            architectural_candidates.append(function_candidate)

    # ---------------------------------------------------------------
    # INTEGRATED AGGREGATION (M21.13)
    # ---------------------------------------------------------------

    all_candidates = aggregate_candidates(
        structural_candidates=structural_candidates,
        subquery_candidates=subquery_result.candidates,
        architectural_candidates=architectural_candidates,
        tables=tables,
    )

    # ---------------------------------------------------------------
    # SAFE VALIDATION + BENCHMARK (M21.18 guard, M21.14 benchmark)
    # ---------------------------------------------------------------

    benchmark_evidence = []
    if run_benchmark and all_candidates:
        benchmark_evidence, bench_diagnostics = benchmark_candidates(all_candidates)
        diagnostics.extend(
            f"{d.candidate_id}: {d.detail}" for d in bench_diagnostics if d.detail
        )

    # ---------------------------------------------------------------
    # REPORT (M21.15)
    # ---------------------------------------------------------------

    report = build_optimization_report(
        validation, analysis, all_candidates, benchmark_evidence
    )

    return StudioPipelineResult(report=report, diagnostics=diagnostics)
