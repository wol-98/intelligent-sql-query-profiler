"""
M21.15 — Dynamic Optimization Blueprint
--------------------------------------------
Assembles the final OptimizationReport for one analyzed query.

RESOLVED AMBIGUITY: the M21 milestone table describes this as using
"the five-section reporting format" without defining the sections
anywhere in the docs I had access to. OptimizationReport
(api/schemas/structural_optimization.py) has exactly five fields:

  1. query_validation        — was the SQL valid/supported? (M21.2)
  2. structural_analysis     — what does the query's structure look like? (M21.4-9)
  3. candidates               — what optimizations were proposed? (M21.4-13)
  4. benchmark_evidence       — what did benchmarking actually measure? (M21.14)
  5. overall_evidence_status  — the report's own honesty check on itself

That IS the five-section format — this module's only real job is
computing #5 correctly from #4, since the other four sections are
simply passed through from earlier pipeline stages.
"""

from __future__ import annotations

from api.schemas.structural_optimization import (
    BenchmarkEvidence,
    EvidenceStatus,
    OptimizationCandidate,
    OptimizationReport,
    QueryValidationResult,
    StructuralAnalysis,
)

# Worst-case-wins ordering: if ANY benchmark has weaker evidence than
# COMPLETE, the report as a whole cannot claim COMPLETE evidence.
_SEVERITY_ORDER = {
    EvidenceStatus.INSUFFICIENT: 0,
    EvidenceStatus.PARTIAL: 1,
    EvidenceStatus.COMPLETE: 2,
}


def _compute_overall_evidence_status(
    candidates: list[OptimizationCandidate],
    benchmark_evidence: list[BenchmarkEvidence],
) -> EvidenceStatus:
    if not candidates:
        # No optimization opportunities identified — nothing to have
        # evidence about, so there's nothing insufficient either.
        # This is a deliberate judgment call: "no candidates" is
        # treated as COMPLETE evidence that no candidates exist, not
        # as an unverified/insufficient state. Flagged for review if
        # the team wants different behavior here.
        return EvidenceStatus.COMPLETE

    if not benchmark_evidence:
        return EvidenceStatus.INSUFFICIENT

    worst = min(
        (_SEVERITY_ORDER[evidence.evidence_status] for evidence in benchmark_evidence),
        default=_SEVERITY_ORDER[EvidenceStatus.INSUFFICIENT],
    )
    return {v: k for k, v in _SEVERITY_ORDER.items()}[worst]


def build_optimization_report(
    query_validation: QueryValidationResult,
    structural_analysis: StructuralAnalysis,
    candidates: list[OptimizationCandidate],
    benchmark_evidence: list[BenchmarkEvidence],
) -> OptimizationReport:
    """
    Assembles the five-section OptimizationReport. Pure assembly +
    one derived field (overall_evidence_status) — does not re-run
    any analysis, generation, or benchmarking itself.
    """

    return OptimizationReport(
        query_validation=query_validation,
        structural_analysis=structural_analysis,
        candidates=candidates,
        benchmark_evidence=benchmark_evidence,
        overall_evidence_status=_compute_overall_evidence_status(
            candidates, benchmark_evidence
        ),
    )
