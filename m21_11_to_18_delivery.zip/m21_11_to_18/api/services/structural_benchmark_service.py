"""
M21.14 — Alternative-Query Benchmarking
-------------------------------------------
Benchmarks a candidate's rewritten SQL (optimized_sql or
architectural_recommendation) against the original query, using the
same EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) approach already proven
in collector/benchmark_runner.py — reused here rather than
reimplemented, via benchmark_query().

Every execution is gated by execution_safety_guard.guard_before_execution()
(M21.18) as a second, independent safety layer beyond M21.2's
structural_sql_validator.

Candidates with no rewritten SQL available (optimized_sql is None,
which is the default for freshly generated candidates — see
structural_candidate_generator.py and structural_subquery_candidate_generator.py)
are reported as INSUFFICIENT evidence rather than skipped silently or
benchmarked against nothing.

IMPORTANT — BenchmarkEvidence (api/schemas/structural_optimization.py)
has no free-text "notes" field. Refusal/failure reasons are therefore
NOT stored on the returned object — this function also returns them
via BenchmarkDiagnostics for callers (the Studio pipeline, logs) that
want the detail; the OptimizationReport itself only ever sees the
schema-defined fields.

This module cannot be exercised end-to-end without a live PostgreSQL
connection. benchmark_candidate() accepts an injectable `runner`
callable specifically so it can be unit-tested with a fake runner.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from api.schemas.structural_optimization import (
    BenchmarkEvidence,
    EvidenceStatus,
)
from api.services.execution_safety_guard import guard_before_execution

BenchmarkRunner = Callable[[str], dict]

DEFAULT_ITERATIONS = 5
DEFAULT_WARMUP_RUNS = 1


@dataclass(frozen=True)
class BenchmarkDiagnostics:
    """Non-schema companion to BenchmarkEvidence, for logs/API
    responses that want the human-readable reason behind a
    PARTIAL/INSUFFICIENT result. Never placed inside the
    OptimizationReport itself."""
    candidate_id: str
    detail: str | None


def _real_runner(sql: str) -> dict:
    """Delegates to the existing, already-tested
    collector.benchmark_runner.benchmark_query(). Imported lazily so
    this module can be imported (and unit-tested with a fake runner)
    without requiring psycopg2/a live DB connection at import time."""
    from collector.benchmark_runner import benchmark_query

    return benchmark_query(
        sql, iterations=DEFAULT_ITERATIONS, warmup_runs=DEFAULT_WARMUP_RUNS
    )


def _rows_preserved(baseline: dict, alternative: dict) -> bool | None:
    baseline_rows = baseline.get("average_rows")
    alternative_rows = alternative.get("average_rows")
    if baseline_rows is None or alternative_rows is None:
        return None
    return abs(baseline_rows - alternative_rows) < 0.5


def _plan_changed(baseline: dict, alternative: dict) -> bool | None:
    baseline_plan = baseline.get("representative_plan")
    alternative_plan = alternative.get("representative_plan")
    if baseline_plan is None or alternative_plan is None:
        return None
    return baseline_plan.get("Node Type") != alternative_plan.get("Node Type")


def benchmark_candidate(
    candidate_id: str,
    original_sql: str,
    rewritten_sql: str | None,
    *,
    runner: BenchmarkRunner = _real_runner,
) -> tuple[BenchmarkEvidence, BenchmarkDiagnostics]:
    """
    Benchmarks one candidate's rewritten SQL against its original.

    Returns (BenchmarkEvidence, BenchmarkDiagnostics). evidence_status:
      - INSUFFICIENT : no rewritten SQL was available to benchmark,
                        a safety check refused execution, or execution failed
      - PARTIAL      : one side executed but comparison is incomplete
      - COMPLETE     : both sides executed and were compared
    """

    if not rewritten_sql:
        return (
            BenchmarkEvidence(
                candidate_id=candidate_id,
                evidence_status=EvidenceStatus.INSUFFICIENT,
            ),
            BenchmarkDiagnostics(
                candidate_id,
                "No rewritten SQL available yet (optimized_sql / "
                "architectural_recommendation is None) — upstream stages "
                "generate candidate shells by design; benchmarking requires "
                "that SQL to be filled in first.",
            ),
        )

    original_guard = guard_before_execution(original_sql)
    rewritten_guard = guard_before_execution(rewritten_sql)

    if not original_guard["is_safe"] or not rewritten_guard["is_safe"]:
        reasons = original_guard["reasons"] + rewritten_guard["reasons"]
        return (
            BenchmarkEvidence(
                candidate_id=candidate_id,
                evidence_status=EvidenceStatus.INSUFFICIENT,
            ),
            BenchmarkDiagnostics(
                candidate_id, "Execution refused by safety guard: " + "; ".join(reasons)
            ),
        )

    try:
        baseline = runner(original_sql)
        alternative = runner(rewritten_sql)
    except Exception as exc:  # pragma: no cover - depends on live DB
        return (
            BenchmarkEvidence(
                candidate_id=candidate_id,
                evidence_status=EvidenceStatus.INSUFFICIENT,
            ),
            BenchmarkDiagnostics(candidate_id, f"Benchmark execution failed: {exc}"),
        )

    baseline_ms = baseline.get("average_execution_time_ms")
    alternative_ms = alternative.get("average_execution_time_ms")

    if baseline_ms is None or alternative_ms is None:
        return (
            BenchmarkEvidence(
                candidate_id=candidate_id,
                evidence_status=EvidenceStatus.PARTIAL,
                baseline_time_ms=baseline_ms,
                alternative_time_ms=alternative_ms,
            ),
            BenchmarkDiagnostics(
                candidate_id, "One or both benchmark runs did not report execution time."
            ),
        )

    improvement_percent = (
        round((baseline_ms - alternative_ms) / baseline_ms * 100, 2)
        if baseline_ms > 0
        else None
    )
    savings_ms = round(baseline_ms - alternative_ms, 3)

    return (
        BenchmarkEvidence(
            candidate_id=candidate_id,
            evidence_status=EvidenceStatus.COMPLETE,
            baseline_time_ms=round(baseline_ms, 3),
            alternative_time_ms=round(alternative_ms, 3),
            improvement_percent=improvement_percent,
            savings_ms=savings_ms,
            rows_preserved=_rows_preserved(baseline, alternative),
            plan_changed=_plan_changed(baseline, alternative),
        ),
        BenchmarkDiagnostics(candidate_id, None),
    )


def benchmark_candidates(
    candidates: list,
    *,
    runner: BenchmarkRunner = _real_runner,
) -> tuple[list[BenchmarkEvidence], list[BenchmarkDiagnostics]]:
    """
    Batch entry point — benchmarks every candidate whose optimized_sql
    or architectural_recommendation is populated. INDEX candidates are
    skipped here (index creation/benchmarking is the separate,
    already-existing M1-M20 flow — collector/index_validator.py and
    collector/benchmark_runner.py — not duplicated in this module).

    Returns (evidence_list, diagnostics_list) — same order as
    `candidates`, aligned by index.
    """

    evidence_list: list[BenchmarkEvidence] = []
    diagnostics_list: list[BenchmarkDiagnostics] = []

    for candidate in candidates:
        rewritten_sql = candidate.optimized_sql or candidate.architectural_recommendation
        evidence, diagnostics = benchmark_candidate(
            candidate.candidate_id, candidate.original_sql, rewritten_sql, runner=runner
        )
        evidence_list.append(evidence)
        diagnostics_list.append(diagnostics)

    return evidence_list, diagnostics_list
