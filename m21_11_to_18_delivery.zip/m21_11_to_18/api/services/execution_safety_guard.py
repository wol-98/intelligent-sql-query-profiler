"""
M21.18 (safety component) — Execution Safety Guard
------------------------------------------------------
Defense-in-depth check applied immediately before ANY SQL is executed
against the live database (i.e. inside structural_benchmark_service.py,
right before EXPLAIN ANALYZE runs).

M21.2's structural_sql_validator.py already rejects non-SELECT
statements using sqlglot's statement classification. This guard is a
SECOND, independent layer specifically at the execution boundary —
it does not replace M21.2, and M21.2 should not be weakened on the
assumption this guard exists elsewhere. Two independent checks with
different implementations (AST-based vs. keyword/regex-based) catch
different classes of parser edge cases.

The DB connection used for benchmarking (config/database.py) should
ALSO be a read-only Postgres role. This guard is not the only line of
defense — say this explicitly to whoever manages DB credentials.
"""

from __future__ import annotations

import re

_FORBIDDEN_KEYWORDS = [
    "DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "TRUNCATE",
    "GRANT", "REVOKE", "CREATE", "EXECUTE", "CALL", "COPY",
    "VACUUM", "REINDEX", "CLUSTER", "SET", "RESET", "LOCK",
    "DO", "MERGE", "PG_SLEEP", "DBLINK", "PG_TERMINATE_BACKEND",
]

_ALLOWED_START_PATTERN = re.compile(r'^\s*(SELECT|WITH)\b', re.IGNORECASE)
_STATEMENT_SPLIT_PATTERN = re.compile(r';')


def _strip_comments(sql: str) -> str:
    sql = re.sub(r'--.*?\n', '\n', sql)
    sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
    return sql


def guard_before_execution(sql_text: str) -> dict:
    """
    Returns {"is_safe": bool, "reasons": list[str]}.

    Callers (structural_benchmark_service.py) MUST check is_safe and
    refuse to execute when False — this function only evaluates, it
    does not raise, so the caller's control flow stays explicit.
    """

    reasons: list[str] = []

    if not sql_text or not sql_text.strip():
        return {"is_safe": False, "reasons": ["Empty SQL — refusing to execute."]}

    cleaned = _strip_comments(sql_text).strip()

    statements = [s.strip() for s in _STATEMENT_SPLIT_PATTERN.split(cleaned) if s.strip()]
    if len(statements) > 1:
        reasons.append(
            f"Multiple statements detected ({len(statements)}) — refusing to "
            f"execute more than one statement per benchmark run."
        )

    if not _ALLOWED_START_PATTERN.match(cleaned):
        reasons.append("Statement does not start with SELECT/WITH — refusing to execute.")

    for keyword in _FORBIDDEN_KEYWORDS:
        if re.search(rf'\b{keyword}\b', cleaned, re.IGNORECASE):
            reasons.append(f"Forbidden keyword detected: {keyword} — refusing to execute.")

    return {"is_safe": len(reasons) == 0, "reasons": reasons}
