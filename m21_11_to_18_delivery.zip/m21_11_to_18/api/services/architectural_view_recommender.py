"""
M21.11 — Architectural View Recommender
-----------------------------------------
Upgrades structural opportunities (JOIN_ANALYSIS, AGGREGATION_ANALYSIS)
into ARCHITECTURAL optimization candidates recommending a VIEW or
MATERIALIZED VIEW, when the underlying query is both structurally
complex and observed to run repeatedly.

This service is analytical only. It does not:
  - execute SQL,
  - create views or materialized views,
  - modify the database,
  - benchmark alternatives, or
  - make optimization decisions.

Candidates generated here follow the same CANDIDATE lifecycle as
every other M21 candidate (api/schemas/structural_optimization.py) —
they are proposals, not applied changes.

NOTE ON OPPORTUNITY TYPES: OptimizationOpportunityType has no
dedicated "view"/"materialized view" member. This service instead
reads the underlying StructuralAnalysis directly (joins_detected,
aggregates_detected, layers_detected) rather than the opportunity
list, because "this query is a good view candidate" is a judgment
about the whole query's shape and repetition, not about one isolated
finding. This is a deliberate interpretation — flagged for review
against however the team defines M21.11's exact trigger condition.
"""

from __future__ import annotations

from api.schemas.structural_optimization import (
    AlternativeType,
    CandidateStatus,
    OptimizationCandidate,
    StructuralAnalysis,
    StructuralLayer,
)

# Thresholds are starting points, not tuned values — surface these as
# configuration once real workload frequency data is available.
FREQUENCY_THRESHOLD = 2
MATERIALIZED_JOIN_THRESHOLD = 2
MATERIALIZED_AGGREGATE_THRESHOLD = 2
DEFAULT_REFRESH_INTERVAL = "1 hour"


class ArchitecturalViewRecommender:
    """Recommend VIEW / MATERIALIZED VIEW candidates for repeated,
    structurally complex queries."""

    def recommend(
        self,
        analysis: StructuralAnalysis,
        original_sql: str,
        *,
        execution_frequency: int,
        candidate_id: str,
        view_name: str,
    ) -> OptimizationCandidate | None:
        """
        Returns an OptimizationCandidate with alternative_type=ARCHITECTURAL,
        or None if this query does not meet the view-candidate bar.

        Parameters
        ----------
        analysis : StructuralAnalysis
            Output of StructuralSQLAnalyzer.analyze() for this query.
        original_sql : str
            The validated, normalized SQL text (from QueryValidationResult).
        execution_frequency : int
            How many times this exact query shape has been observed to
            run. Callers should supply this from query-fingerprint
            frequency tracking (see collector/query_parser.py's
            fingerprinting) — not invented here.
        candidate_id : str
            Caller-assigned deterministic ID (e.g. "ARCH-VIEW-0001"),
            consistent with the ID scheme used by
            StructuralCandidateGenerator.
        view_name : str
            Caller-assigned view name. Kept as a caller responsibility
            so naming stays consistent with whatever convention the
            team settles on (this service does not invent table-name
            based slugs to avoid colliding with the existing
            collector/view_recommender-style naming from earlier work).
        """

        if execution_frequency < FREQUENCY_THRESHOLD:
            return None

        if not self._is_view_candidate(analysis):
            return None

        materialize = self._should_materialize(analysis)
        recommendation_sql = self._build_view_sql(
            view_name, original_sql, materialize
        )

        reasoning_parts = [f"observed {execution_frequency}x with the same query shape"]
        if analysis.joins_detected:
            reasoning_parts.append(f"{analysis.joins_detected} join(s)")
        if analysis.aggregates_detected:
            reasoning_parts.append(f"{analysis.aggregates_detected} aggregate(s)")
        if StructuralLayer.GROUP_BY in analysis.layers_detected:
            reasoning_parts.append("GROUP BY present")

        rationale = (
            f"Repeated, structurally complex query — {'; '.join(reasoning_parts)}. "
            f"Recommending a {'MATERIALIZED VIEW' if materialize else 'VIEW'} as an "
            f"ARCHITECTURAL candidate. This candidate is unvalidated — no semantic "
            f"equivalence or performance improvement has been established at this stage."
        )

        return OptimizationCandidate(
            candidate_id=candidate_id,
            alternative_type=AlternativeType.ARCHITECTURAL,
            status=CandidateStatus.CANDIDATE,
            title=(
                "Materialized view candidate" if materialize else "View candidate"
            ),
            rationale=rationale,
            source_layer=StructuralLayer.FROM,
            original_sql=original_sql,
            optimized_sql=None,
            index_ddl=None,
            architectural_recommendation=recommendation_sql,
        )

    @staticmethod
    def _is_view_candidate(analysis: StructuralAnalysis) -> bool:
        has_join = bool(analysis.joins_detected)
        has_group_by = StructuralLayer.GROUP_BY in analysis.layers_detected
        has_aggregate = bool(analysis.aggregates_detected)
        return has_join or has_group_by or has_aggregate

    @staticmethod
    def _should_materialize(analysis: StructuralAnalysis) -> bool:
        joins = analysis.joins_detected or 0
        aggregates = analysis.aggregates_detected or 0
        return (
            joins >= MATERIALIZED_JOIN_THRESHOLD
            or aggregates >= MATERIALIZED_AGGREGATE_THRESHOLD
        )

    @staticmethod
    def _build_view_sql(view_name: str, original_sql: str, materialize: bool) -> str:
        kind = "MATERIALIZED VIEW" if materialize else "VIEW"
        statement = f"CREATE {kind} {view_name} AS\n{original_sql.strip().rstrip(';')};"
        if materialize:
            statement += (
                f"\n-- Suggested refresh cadence: {DEFAULT_REFRESH_INTERVAL} "
                "(placeholder — should be set from real workload timing once available)"
                f"\nREFRESH MATERIALIZED VIEW {view_name};"
            )
        return statement
