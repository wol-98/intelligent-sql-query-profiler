"""
CHANGES FROM ORIGINAL main.py — flagged explicitly, not silently made:

1. Added: `from api.routes import studio` + `app.include_router(studio.router)`
2. Changed: CORSMiddleware allow_methods from ["GET"] to ["GET", "POST"]

Change #2 matters: this API's docstring below describes it as a
"Read-only reporting API." Adding POST is a real architecture change,
not a routine addition — get sign-off from whoever owns that
decision before merging this. Everything else in this file is
unchanged from the original.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import cost_benefit
from api.routes import composite
from api.routes import decisions
from api.routes import queries
from api.routes import benchmarks
from api.routes import provenance
from api.routes import studio

from api.routes.overview import (
    router as overview_router,
)

from api.routes.workloads import router as workloads_router
from api.routes.recommendations import (
    router as recommendations_router,
)


app = FastAPI(
    title=(
        "Intelligent SQL Query Profiler "
        "& Index Optimization Engine"
    ),
    description=(
        "Reporting API for the M20 Optimization Intelligence "
        "Dashboard, plus the M21 Dynamic SQL Optimization Studio "
        "(POST /api/studio/analyze)."
    ),
    version="1.1.0",
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


app.include_router(
    overview_router
)

app.include_router(
    recommendations_router
)
app.include_router(
    workloads_router)

app.include_router(
    cost_benefit.router)

app.include_router(
    composite.router
)

app.include_router(
    decisions.router
)
app.include_router(
    queries.router
)
app.include_router(
    benchmarks.router)
app.include_router(
    provenance.router)
app.include_router(
    studio.router)
@app.get("/api/health")
def health_check() -> dict[str, str]:
    return {
        "status": "ok",
        "service": "m20-reporting-api",
    }
