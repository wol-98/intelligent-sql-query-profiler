"""
Studio Route (M21.16 backend)
----------------------------------
POST /api/studio/analyze — the ONE write-shaped* endpoint in this
API. Every other route in api/routes/ is GET-only, and main.py's
CORS middleware currently only allows_methods=["GET"] — see the
main.py changes in this delivery. Adding this endpoint is an
architecture change (this API was explicitly documented as
"Read-only reporting API") and should get a sign-off from whoever
owns that decision, not be treated as a routine addition.

* "write-shaped" because it accepts a POST body, but it does not
write to the application database — it returns an analysis. If
run_benchmark=True, it DOES execute SELECT-only SQL against the
target database being profiled (gated by M21.2 + M21.18's two
independent safety layers) — that's a different kind of write-risk
than mutating this app's own data, but still worth calling out
explicitly to the team.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from api.schemas.studio import StudioAnalyzeRequest, StudioAnalyzeResponse
from api.services.studio_pipeline_service import run_studio_pipeline

router = APIRouter(prefix="/api/studio", tags=["Studio"])


@router.post("/analyze", response_model=StudioAnalyzeResponse)
def analyze_query(request: StudioAnalyzeRequest) -> StudioAnalyzeResponse:
    """
    Runs the full M21 pipeline (validate -> schema check -> parse ->
    structural analysis -> candidate generation -> optional benchmark
    -> report) for one submitted SQL query.
    """

    try:
        result = run_studio_pipeline(
            request.sql,
            execution_frequency=request.execution_frequency,
            where_predicate_columns=request.where_predicate_columns,
            run_benchmark=request.run_benchmark,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return StudioAnalyzeResponse(report=result.report, diagnostics=result.diagnostics)
