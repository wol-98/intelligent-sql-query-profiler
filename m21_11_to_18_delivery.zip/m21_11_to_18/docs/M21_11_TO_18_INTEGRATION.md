# M21.11–18 — Delivery Notes

## What changed since the last version of this work

The previous round of M21.11–18 code (view/function recommenders, aggregator,
benchmark stub, report builder, safety validator, mock Studio) was built
**before** I had access to the real repo. It used invented shapes
(`"type": "view"/"index"/"function"`, plain dicts). **This version is a full
rewrite against the actual Pydantic contracts** in
`api/schemas/structural_optimization.py`, and against the real M21.1–10
services already in the repo (`StructuralSQLAnalyzer`,
`StructuralOpportunityAnalyzer`, `StructuralCandidateGenerator`,
`StructuralSubqueryCandidateGenerator`, `structural_sql_validator.validate_sql`,
`schema_validator.validate_tables`). Nothing here was written from scratch
without checking the real code — every field name and function signature
was verified against the actual files before use.

## File map

| File | Milestone | What it does |
|---|---|---|
| `api/services/architectural_view_recommender.py` | M21.11 | Upgrades repeated, complex queries to VIEW/MATERIALIZED VIEW `OptimizationCandidate`s (`AlternativeType.ARCHITECTURAL`) |
| `api/services/architectural_function_recommender.py` | M21.12 | Same, but for parameterized SQL functions on high-frequency, predicate-driven queries |
| `api/services/integrated_candidate_aggregator.py` | M21.13 | Merges INDEX/SQL_REWRITE candidates, subquery-alternative candidates, and my ARCHITECTURAL candidates into one list; flags possible index/materialized-view redundancy |
| `api/services/execution_safety_guard.py` | M21.18 (safety) | Second, independent safety layer at the execution boundary, alongside M21.2's `structural_sql_validator` |
| `api/services/structural_benchmark_service.py` | M21.14 | Benchmarks a candidate's rewritten SQL against the original, reusing `collector/benchmark_runner.py`'s proven `EXPLAIN ANALYZE` approach |
| `api/services/optimization_report_builder.py` | M21.15 | Assembles the `OptimizationReport` — **this IS the five-section format** (see below) |
| `api/services/studio_pipeline_service.py` | M21.16 backend | Orchestrates M21.2 → M21.15 for one submitted query |
| `api/schemas/studio.py`, `api/routes/studio.py` | M21.16 backend | Request/response shapes + the one POST endpoint |
| `api/main.py` | — | Wires in the Studio route; **changes CORS to allow POST** — flagged, needs sign-off (see below) |
| `dashboard/src/pages/StudioPage.jsx` | M21.16 + M21.17 | The actual Studio UI — submit SQL, see all five report sections, click a candidate to preview its SQL, click a benchmark bar to cross-filter |
| `dashboard/src/components/studio/BenchmarkBarChart.jsx` | M21.17 | Hand-built SVG bar chart (no chart library exists in `package.json` yet — flagged as a choice, not an oversight) |
| `dashboard/src/api/studio.js` | — | API client function, same pattern as the existing `api/client.js` |
| `dashboard/src/components/layout/Sidebar.jsx`, `dashboard/src/App.jsx` | — | Adds "Optimization Studio" nav entry and routes to it |

## The M21.15 ambiguity is now resolved

`OptimizationReport` has exactly five fields: `query_validation`,
`structural_analysis`, `candidates`, `benchmark_evidence`,
`overall_evidence_status`. **That is the five-section format.** My earlier
guess (Query Summary / Structural Analysis / Recommendations / Benchmark
Evidence / Cost-Benefit Verdict) was close in spirit but not the real shape —
this version uses the actual model directly, no guessing.

## Things that still need a decision from the team

1. **`api/main.py` changes CORS from `["GET"]` to `["GET", "POST"]`.** The API
   is explicitly documented as "read-only reporting API." Adding a POST
   endpoint is a real architecture decision — get sign-off before merging,
   don't treat it as routine.
2. **Schema validation (M21.3) requires a live DB connection.** The Studio
   pipeline treats this as best-effort — if no `DATABASE_URL` is configured,
   schema checking is skipped and noted in `diagnostics`, not hard-failed.
   Confirm this is the behavior the team wants.
3. **`execution_frequency` defaults to 1** for ad-hoc Studio submissions,
   which means M21.11/12's view/function recommendations mostly won't fire
   for one-off queries (their thresholds are 2 and 3 respectively). To get
   real recommendations for known workload queries, pass the actual
   frequency from query-fingerprint tracking — the orchestrator accepts this
   as a parameter for exactly that reason.
4. **`ArchitecturalFunctionRecommender` produces a SQL skeleton, not
   production-ready code** — parameter types are guessed from column-name
   conventions, and literal-to-parameter substitution is left as `-- TODO`
   comments in the generated SQL. This needs either real schema type lookups
   or a proper SQL-rewrite pass before the generated function SQL is usable.
5. **`structural_benchmark_service.py` cannot be exercised end-to-end without
   a live PostgreSQL connection** — I don't have one in this environment. It
   accepts an injectable `runner` so it can be unit-tested with a fake
   runner; the real path (`collector.benchmark_runner.benchmark_query`) is
   the same code already used and proven elsewhere in the repo, just called
   from a new place.
6. **No file here could be executed in this sandbox** — `pydantic`,
   `sqlglot`, and `fastapi` aren't installed and there's no network access to
   install them. Every file passed a Python syntax check (`py_compile`) and
   was manually checked field-by-field against the real schema file, but
   none of it has actually been run. **Run the test suite (`pytest`) against
   this before treating it as done** — that's a real gap, not a formality.

## Suggested test additions

Following the existing test style in `tests/test_structural_candidate_generator.py`,
the team should add:
- `tests/test_architectural_view_recommender.py`
- `tests/test_architectural_function_recommender.py`
- `tests/test_integrated_candidate_aggregator.py`
- `tests/test_optimization_report_builder.py`
- `tests/test_studio_pipeline_service.py` (with a fake DB/benchmark runner injected)

I did not write these myself — didn't want to write tests against code I
couldn't actually execute and verify pass/fail in this environment. Happy to
draft them once someone can run `pytest` against this and confirm the real
API surfaces match what's assumed here.
